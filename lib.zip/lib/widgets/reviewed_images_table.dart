// ─────────────────────────────────────────────────────────────────────────────
// ReviewedImagesTable — Photos | Land Usage | Crop/Area Type | Area
// Changes:
//   • Added optional onImageTap(index) callback — tapping a thumbnail opens
//     the fullscreen photo viewer at that index
// ─────────────────────────────────────────────────────────────────────────────
import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/app_dimensions.dart';
import '../models/survey_model.dart';

class ReviewedImagesTable extends StatelessWidget {
  final List<SurveyImage> images;

  /// Called with the tapped row's index when a thumbnail is tapped.
  /// If null, thumbnails are not interactive.
  final void Function(int index)? onImageTap;

  const ReviewedImagesTable({
    super.key,
    required this.images,
    this.onImageTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildHeader(context),
        ...images.asMap().entries.map(
              (e) => _buildRow(context, e.value, e.key, isLast: e.key == images.length - 1),
            ),
      ],
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: context.getHeight(8)),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: context.getWidth(52),
            child: Text('PHOTOS', style: _headerStyle(context)),
          ),
          Expanded(
            flex: 3,
            child: Text('LAND USAGE ↕', style: _headerStyle(context)),
          ),
          Expanded(
            flex: 2,
            child: Text('CROP /\nAREA TYPE ↕', style: _headerStyle(context)),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'AREA ↕',
              style: _headerStyle(context),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(
    BuildContext context,
    SurveyImage img,
    int index, {
    required bool isLast,
  }) {
    final canTap = onImageTap != null;

    return Container(
      padding: EdgeInsets.symmetric(vertical: context.getHeight(10)),
      decoration: BoxDecoration(
        border: isLast
            ? null
            : const Border(
                bottom: BorderSide(color: AppColors.divider, width: 0.5),
              ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Thumbnail — tappable when onImageTap is provided
          SizedBox(
            width: context.getWidth(52),
            child: GestureDetector(
              onTap: canTap ? () => onImageTap!(index) : null,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(context.getWidth(6)),
                    child: SizedBox(
                      width: context.getWidth(40),
                      height: context.getHeight(30),
                      child: CustomPaint(
                        painter: _MiniFieldPainter(Color(img.colorHex)),
                      ),
                    ),
                  ),
                  // Tap hint overlay — only shown when interactive
                  if (canTap)
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius:
                            BorderRadius.circular(context.getWidth(6)),
                        child: Container(
                          width: context.getWidth(40),
                          height: context.getHeight(30),
                          color: Colors.black.withValues(alpha: 0.22),
                          child: Icon(
                            Icons.zoom_in_rounded,
                            color: Colors.white,
                            size: context.getWidth(14),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              img.landUsage,
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontS),
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              img.cropAreaType,
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontS),
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  img.area.toStringAsFixed(3),
                  style: TextStyle(
                    fontSize: context.getFontSize(AppDimens.fontS),
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  img.areaUnit,
                  style: TextStyle(
                    fontSize: context.getFontSize(AppDimens.fontXS),
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  TextStyle _headerStyle(BuildContext context) => TextStyle(
        fontSize: context.getFontSize(AppDimens.fontXS),
        fontWeight: FontWeight.w700,
        color: AppColors.textSecondary,
        letterSpacing: 0.4,
      );
}

// Mini thumbnail painter
class _MiniFieldPainter extends CustomPainter {
  final Color base;
  _MiniFieldPainter(this.base);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = base,
    );
    final p = Paint()
      ..color = Colors.black.withValues(alpha: 0.18)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    for (double i = -size.height; i < size.width; i += 5) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supervisor_portal_design/core/app_colors.dart';
import 'package:supervisor_portal_design/core/app_state.dart';
import 'package:supervisor_portal_design/screens/login_screen.dart';
import 'package:supervisor_portal_design/screens/survey_list_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Supervisor Portal',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        useMaterial3: true,
        fontFamily: 'Segoe UI',
        scaffoldBackgroundColor: AppColors.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.surface,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      // Show login first; SurveyListScreen if already logged in (won't happen
      // in this session since AppState is in-memory, but kept for extensibility)
      home: AppState.instance.isLoggedIn
          ? const SurveyListScreen()
          : const LoginScreen(),
    );
  }
}

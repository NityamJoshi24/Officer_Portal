import 'package:flutter/material.dart';
import 'package:supervisor_portal_design/core/app_dimensions.dart';

import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../data/survey_dummy_data.dart';
import '../models/survey_model.dart';
import 'survey_detail_screen.dart';
import 'login_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
// SurveyListScreen
// Changes from original:
//   • No notification icon in app bar
//   • No bottom navigation bar
//   • Hamburger menu → Drawer with profile + logout
//   • Stat cards no longer show "12% from yesterday" / "Last: 20m ago"
//   • Filters (taluka, village, status) are stored in AppState.instance.filters
//     so they survive navigation to SurveyDetailScreen and back
//   • Load More Surveys button removed
// ─────────────────────────────────────────────────────────────────────────────

class SurveyListScreen extends StatefulWidget {
  const SurveyListScreen({super.key});

  @override
  State<SurveyListScreen> createState() => _SurveyListScreenState();
}

class _SurveyListScreenState extends State<SurveyListScreen> {
  // All surveys — single source of truth
  final List<SurveyModel> _allSurveys = dummySurveys;

  // Convenience shortcut to persistent filters
  FilterState get _f => AppState.instance.filters;

  // ── Derived: unique taluka + village options ──────────────────────────
  late final List<String> _talukaOptions;
  late final List<String> _villageOptions;

  @override
  void initState() {
    super.initState();
    _talukaOptions = _allSurveys.map((s) => s.taluka).toSet().toList()..sort();
    _villageOptions = _allSurveys.map((s) => s.village).toSet().toList()..sort();
  }

  // ── Filtered list ─────────────────────────────────────────────────────
  List<SurveyModel> get _filtered {
    return _allSurveys.where((s) {
      final tOk = _f.talukaFilter.isEmpty || s.taluka == _f.talukaFilter;
      final vOk = _f.villageFilter.isEmpty || s.village == _f.villageFilter;
      final sOk = _f.statusFilter == 'ALL' ||
          (_f.statusFilter == 'PENDING'  && s.status == SurveyStatus.pending)  ||
          (_f.statusFilter == 'APPROVED' && s.status == SurveyStatus.approved) ||
          (_f.statusFilter == 'REJECTED' && s.status == SurveyStatus.rejected);
      return tOk && vOk && sOk;
    }).toList();
  }

  // ── Stats (live) ──────────────────────────────────────────────────────
  int get _pendingCount  => _allSurveys.where((s) => s.status == SurveyStatus.pending).length;
  int get _approvedCount => _allSurveys.where((s) => s.status == SurveyStatus.approved).length;
  int get _rejectedCount => _allSurveys.where((s) => s.status == SurveyStatus.rejected).length;

  // ── Month helper ──────────────────────────────────────────────────────
  String _mon(int m) => const ['','Jan','Feb','Mar','Apr','May','Jun',
      'Jul','Aug','Sep','Oct','Nov','Dec'][m];

  // ── Navigation ────────────────────────────────────────────────────────
  void _openDetail(int allSurveysIndex) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SurveyDetailScreen(
          surveys: _allSurveys,
          initialIndex: allSurveysIndex,
        ),
      ),
    ).then((_) => setState(() {})); // refresh status + stats on return
  }

  void _logout() {
    AppState.instance.logout();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LoginScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    final user = AppState.instance.currentUser;
    final initials = (user?.name ?? 'U')
        .split(' ')
        .take(2)
        .map((w) => w.isNotEmpty ? w[0] : '')
        .join()
        .toUpperCase();

    return Drawer(
      backgroundColor: AppColors.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(context.getWidth(AppDimens.spaceM)),
              color: AppColors.primaryLight,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: context.getWidth(52),
                    height: context.getWidth(52),
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      initials,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: context.getFontSize(AppDimens.fontXL),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  SizedBox(height: context.getHeight(10)),
                  Text(
                    user?.name ?? 'Supervisor',
                    style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontL),
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: context.getHeight(2)),
                  Text(
                    user?.email ?? '',
                    style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontS),
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: context.getHeight(8)),

            // Menu items
            _drawerItem(
              icon: Icons.grid_view_rounded,
              label: 'Surveys',
              onTap: () => Navigator.pop(context),
              active: true,
            ),
            _drawerItem(
              icon: Icons.insert_chart_outlined_rounded,
              label: 'Statistics',
              onTap: () => Navigator.pop(context),
            ),
            _drawerItem(
              icon: Icons.person_outline_rounded,
              label: 'Profile',
              onTap: () => Navigator.pop(context),
            ),
            _drawerItem(
              icon: Icons.settings_outlined,
              label: 'Settings',
              onTap: () => Navigator.pop(context),
            ),

            const Spacer(),

            Divider(color: AppColors.divider, height: context.getHeight(1)),
            SizedBox(height: context.getHeight(4)),

            // Logout
            _drawerItem(
              icon: Icons.logout_rounded,
              label: 'Logout',
              onTap: () {
                Navigator.pop(context);
                _logout();
              },
              iconColor: AppColors.rejected,
              labelColor: AppColors.rejected,
            ),
            SizedBox(height: context.getHeight(12)),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool active = false,
    Color? iconColor,
    Color? labelColor,
  }) {
    final ic = iconColor ?? (active ? AppColors.primaryDark : AppColors.textSecondary);
    final lc = labelColor ?? (active ? AppColors.primaryDark : AppColors.textSecondary);

    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(
          horizontal: context.getWidth(8),
          vertical: context.getHeight(2),
        ),
        padding: EdgeInsets.symmetric(
          horizontal: context.getWidth(12),
          vertical: context.getHeight(12),
        ),
        decoration: BoxDecoration(
          color: active ? AppColors.primaryLight : Colors.transparent,
          borderRadius: BorderRadius.circular(context.getWidth(AppDimens.radiusS)),
        ),
        child: Row(
          children: [
            Icon(icon, size: context.getWidth(AppDimens.iconM), color: ic),
            SizedBox(width: context.getWidth(12)),
            Text(
              label,
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontM),
                fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                color: lc,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── App bar (no notification icon) ───────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      color: AppColors.surface,
      padding: EdgeInsets.fromLTRB(
        context.getWidth(16),
        context.getHeight(10),
        context.getWidth(12),
        context.getHeight(8),
      ),
      child: Row(
        children: [
          // Hamburger → opens drawer
          Builder(
            builder: (ctx) => GestureDetector(
              onTap: () => Scaffold.of(ctx).openDrawer(),
              child: Container(
                width: context.getWidth(36),
                height: context.getWidth(36),
                decoration: const BoxDecoration(
                  color: AppColors.iconBg,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.menu_rounded,
                  color: AppColors.textSecondary,
                  size: context.getWidth(AppDimens.iconM),
                ),
              ),
            ),
          ),
          SizedBox(width: context.getWidth(10)),
          Expanded(
            child: Text(
              'Supervisor Portal',
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontL),
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          // Search button only (no notification)
          _actionButton(Icons.search_rounded),
        ],
      ),
    );
  }

  Widget _actionButton(IconData icon) {
    return Container(
      width: context.getWidth(36),
      height: context.getWidth(36),
      decoration: const BoxDecoration(
        color: AppColors.iconBg,
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: AppColors.textSecondary, size: context.getWidth(AppDimens.iconM - 1)),
    );
  }

  // ── Body ──────────────────────────────────────────────────────────────
  Widget _buildBody() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatusBar(),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: context.getWidth(AppDimens.spaceM),
              vertical: context.getHeight(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStatsCards(),
                SizedBox(height: context.getHeight(14)),
                _buildFilterRow(),
                SizedBox(height: context.getHeight(18)),
                _buildSurveyListHeader(),
                SizedBox(height: context.getHeight(8)),
                _buildSurveyList(),
                // Load More button removed
                SizedBox(height: context.getHeight(16)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Status bar ────────────────────────────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      color: AppColors.surface,
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        context.getWidth(12), 0,
        context.getWidth(12), context.getHeight(12),
      ),
      child: Wrap(
        spacing: context.getWidth(8),
        runSpacing: context.getHeight(8),
        children: [
          _statusBadge(color: AppColors.pending,  bg: AppColors.pendingBg,
              label: 'Pending: $_pendingCount'),
          _statusBadge(color: AppColors.approved, bg: AppColors.approvedBg,
              label: 'Approved: $_approvedCount'),
          _statusBadge(color: AppColors.rejected, bg: AppColors.rejectedBg,
              label: 'Rejected: $_rejectedCount'),
        ],
      ),
    );
  }

  Widget _statusBadge({
    required Color color,
    required Color bg,
    required String label,
  }) {
    final textColor = color == AppColors.pending ? const Color(0xFFB45309) : color;
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: context.getWidth(10),
        vertical: context.getHeight(7),
      ),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(context.getWidth(9)),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: context.getWidth(7),
            height: context.getWidth(7),
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          SizedBox(width: context.getWidth(6)),
          Text(
            label,
            style: TextStyle(
              fontSize: context.getFontSize(11),
              color: textColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ── Stat cards (subtitle removed) ─────────────────────────────────────
  Widget _buildStatsCards() {
    return Row(
      children: [
        Expanded(
          child: _statCard(
            title: 'TOTAL PENDING',
            value: '$_pendingCount',
          ),
        ),
        SizedBox(width: context.getWidth(AppDimens.spaceS)),
        Expanded(
          child: _statCard(
            title: 'REVIEWED TODAY',
            value: '$_approvedCount',
          ),
        ),
      ],
    );
  }

  Widget _statCard({required String title, required String value}) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: context.getWidth(14),
        vertical: context.getHeight(16),
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(context.getWidth(14)),
        border: Border.all(color: AppColors.divider),
        boxShadow: [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: context.getWidth(10),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: context.getFontSize(AppDimens.fontXS),
              color: AppColors.textMuted,
              letterSpacing: 0.9,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: context.getHeight(6)),
          Text(
            value,
            style: TextStyle(
              fontSize: context.getFontSize(AppDimens.fontXXL),
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
              height: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ── Filter row — values stored in AppState so they persist ────────────
  Widget _buildFilterRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: [
          _filterChip(
            icon: Icons.place_outlined,
            label: 'Taluka',
            activeValue: _f.talukaFilter,
            options: _talukaOptions,
            onSelected: (v) => setState(() => _f.talukaFilter = v),
            onCleared: () => setState(() => _f.talukaFilter = ''),
          ),
          SizedBox(width: context.getWidth(10)),
          _filterChip(
            icon: Icons.home_work_outlined,
            label: 'Village',
            activeValue: _f.villageFilter,
            options: _villageOptions,
            onSelected: (v) => setState(() => _f.villageFilter = v),
            onCleared: () => setState(() => _f.villageFilter = ''),
          ),
          SizedBox(width: context.getWidth(10)),
          _statusFilterChip(),
          if (_f.hasActiveFilter) ...[
            SizedBox(width: context.getWidth(10)),
            GestureDetector(
              onTap: () => setState(() => _f.reset()),
              child: Container(
                height: context.getHeight(36),
                padding: EdgeInsets.symmetric(horizontal: context.getWidth(12)),
                decoration: BoxDecoration(
                  color: AppColors.rejectedBg,
                  borderRadius: BorderRadius.circular(context.getWidth(10)),
                  border: Border.all(
                      color: AppColors.rejected.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.close_rounded,
                        size: context.getWidth(14), color: AppColors.rejected),
                    SizedBox(width: context.getWidth(4)),
                    Text(
                      'Clear',
                      style: TextStyle(
                        fontSize: context.getFontSize(AppDimens.fontS),
                        color: AppColors.rejected,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _filterChip({
    required IconData icon,
    required String label,
    required String activeValue,
    required List<String> options,
    required ValueChanged<String> onSelected,
    required VoidCallback onCleared,
  }) {
    final isActive = activeValue.isNotEmpty;
    return GestureDetector(
      onTap: () async {
        final picked = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
                top: Radius.circular(context.getWidth(AppDimens.radiusL))),
          ),
          builder: (ctx) => _filterPickerSheet(
            title: label,
            options: options,
            current: activeValue,
          ),
        );
        if (picked != null) {
          if (picked.isEmpty) {
            onCleared();
          } else {
            onSelected(picked);
          }
        }
      },
      child: Container(
        height: context.getHeight(36),
        padding: EdgeInsets.symmetric(horizontal: context.getWidth(12)),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primaryLight : AppColors.surface,
          borderRadius: BorderRadius.circular(context.getWidth(10)),
          border: Border.all(
            color: isActive
                ? AppColors.primary.withValues(alpha: 0.5)
                : AppColors.chipBorder,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                size: context.getWidth(15),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary),
            SizedBox(width: context.getWidth(6)),
            Text(
              isActive ? activeValue : label,
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontS),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
            SizedBox(width: context.getWidth(4)),
            Icon(Icons.keyboard_arrow_down,
                size: context.getWidth(16),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary),
          ],
        ),
      ),
    );
  }

  Widget _statusFilterChip() {
    final isActive = _f.statusFilter != 'ALL';
    const opts = ['ALL', 'PENDING', 'APPROVED', 'REJECTED'];
    return GestureDetector(
      onTap: () async {
        final picked = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
                top: Radius.circular(context.getWidth(AppDimens.radiusL))),
          ),
          builder: (ctx) => _filterPickerSheet(
            title: 'Status',
            options: opts,
            current: _f.statusFilter,
          ),
        );
        if (picked != null) {
          setState(() => _f.statusFilter = picked.isEmpty ? 'ALL' : picked);
        }
      },
      child: Container(
        height: context.getHeight(36),
        padding: EdgeInsets.symmetric(horizontal: context.getWidth(12)),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primaryLight : AppColors.surface,
          borderRadius: BorderRadius.circular(context.getWidth(10)),
          border: Border.all(
            color: isActive
                ? AppColors.primary.withValues(alpha: 0.5)
                : AppColors.chipBorder,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.filter_list_rounded,
                size: context.getWidth(15),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary),
            SizedBox(width: context.getWidth(6)),
            Text(
              isActive ? _f.statusFilter : 'Status',
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontS),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
            SizedBox(width: context.getWidth(4)),
            Icon(Icons.keyboard_arrow_down,
                size: context.getWidth(16),
                color: isActive ? AppColors.primaryDark : AppColors.textSecondary),
          ],
        ),
      ),
    );
  }

  Widget _filterPickerSheet({
    required String title,
    required List<String> options,
    required String current,
  }) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.6,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Handle bar + title — fixed header
            Padding(
              padding: EdgeInsets.fromLTRB(
                context.getWidth(AppDimens.spaceM),
                context.getWidth(AppDimens.spaceM),
                context.getWidth(AppDimens.spaceM),
                0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: context.getWidth(36),
                      height: context.getHeight(4),
                      decoration: BoxDecoration(
                        color: AppColors.divider,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  SizedBox(height: context.getHeight(14)),
                  Text(
                    'Filter by $title',
                    style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontL),
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: context.getHeight(12)),
                ],
              ),
            ),
            // Scrollable options list
            Flexible(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                    horizontal: context.getWidth(AppDimens.spaceM)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _pickerOption(
                        'All / Clear', '', current == '' || current == 'ALL'),
                    const Divider(color: AppColors.divider, height: 1),
                    ...options.map((o) => Column(
                          children: [
                            _pickerOption(o, o, current == o),
                            if (o != options.last)
                              const Divider(color: AppColors.divider, height: 1),
                          ],
                        )),
                    SizedBox(height: context.getHeight(16)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pickerOption(String display, String value, bool selected) {
    return InkWell(
      onTap: () => Navigator.pop(context, value),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: context.getHeight(12)),
        child: Row(
          children: [
            Expanded(
              child: Text(
                display,
                style: TextStyle(
                  fontSize: context.getFontSize(AppDimens.fontM),
                  color: selected ? AppColors.primaryDark : AppColors.textPrimary,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
            if (selected)
              Icon(Icons.check_rounded,
                  size: context.getWidth(AppDimens.iconM),
                  color: AppColors.primary),
          ],
        ),
      ),
    );
  }

  // ── Survey list header ────────────────────────────────────────────────
  Widget _buildSurveyListHeader() {
    final count = _filtered.length;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Survey Plots',
          style: TextStyle(
            fontSize: context.getFontSize(AppDimens.fontL),
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(
            horizontal: context.getWidth(8),
            vertical: context.getHeight(4),
          ),
          decoration: BoxDecoration(
            color: AppColors.primaryTint,
            borderRadius: BorderRadius.circular(context.getWidth(AppDimens.radiusFull)),
          ),
          child: Text(
            '$count SURVEYS',
            style: TextStyle(
              fontSize: context.getFontSize(AppDimens.fontXS),
              color: AppColors.primaryDark,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ],
    );
  }

  // ── Survey list ───────────────────────────────────────────────────────
  Widget _buildSurveyList() {
    final items = _filtered;
    if (items.isEmpty) {
      return Container(
        padding: EdgeInsets.symmetric(vertical: context.getHeight(40)),
        alignment: Alignment.center,
        child: Column(
          children: [
            Icon(Icons.search_off_rounded,
                size: context.getWidth(40), color: AppColors.divider),
            SizedBox(height: context.getHeight(12)),
            Text(
              'No surveys match your filters.',
              style: TextStyle(
                fontSize: context.getFontSize(AppDimens.fontM),
                color: AppColors.textMuted,
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(context.getWidth(14)),
        border: Border.all(color: AppColors.divider),
        boxShadow: [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: context.getWidth(12),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: items
            .asMap()
            .entries
            .map((e) => _surveyItem(e.value, isLast: e.key == items.length - 1))
            .toList(),
      ),
    );
  }

  Widget _surveyItem(SurveyModel s, {required bool isLast}) {
    final allIndex = _allSurveys.indexOf(s);
    String statusStr;
    switch (s.status) {
      case SurveyStatus.approved: statusStr = 'APPROVED'; break;
      case SurveyStatus.rejected: statusStr = 'REJECTED'; break;
      default: statusStr = 'PENDING';
    }
    final dateStr = '${s.surveyDate.day} ${_mon(s.surveyDate.month)}, ${s.surveyDate.year}';

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _openDetail(allIndex),
      child: Container(
        constraints: BoxConstraints(minHeight: context.getHeight(70)),
        padding: EdgeInsets.symmetric(
          horizontal: context.getWidth(12),
          vertical: context.getHeight(12),
        ),
        decoration: BoxDecoration(
          border: isLast
              ? null
              : const Border(bottom: BorderSide(color: AppColors.divider)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Sequence badge
            Container(
              width: context.getWidth(36),
              height: context.getWidth(36),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(context.getWidth(8)),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.25)),
              ),
              alignment: Alignment.center,
              child: Text(
                '${s.sequenceNumber}',
                style: TextStyle(
                  color: AppColors.primaryDark,
                  fontWeight: FontWeight.w700,
                  fontSize: context.getFontSize(15),
                ),
              ),
            ),
            SizedBox(width: context.getWidth(12)),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Survey ${s.id}',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: context.getFontSize(14),
                          color: AppColors.textPrimary,
                        ),
                      ),
                      _statusPill(statusStr),
                    ],
                  ),
                  SizedBox(height: context.getHeight(3)),
                  Text(
                    s.ownerName,
                    style: TextStyle(
                      fontSize: context.getFontSize(12),
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: context.getHeight(4)),
                  Row(
                    children: [
                      Icon(Icons.location_city_outlined,
                          size: context.getWidth(12), color: AppColors.textMuted),
                      SizedBox(width: context.getWidth(4)),
                      Text(
                        '${s.taluka} Taluka',
                        style: TextStyle(
                          fontSize: context.getFontSize(10),
                          color: AppColors.textMuted,
                        ),
                      ),
                      SizedBox(width: context.getWidth(10)),
                      Icon(Icons.calendar_today_outlined,
                          size: context.getWidth(12), color: AppColors.textMuted),
                      SizedBox(width: context.getWidth(4)),
                      Text(
                        dateStr,
                        style: TextStyle(
                          fontSize: context.getFontSize(10),
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(width: context.getWidth(6)),
            Icon(Icons.chevron_right_rounded,
                color: AppColors.textMuted, size: context.getWidth(18)),
          ],
        ),
      ),
    );
  }

  Widget _statusPill(String status) {
    Color dot, bg, text;
    switch (status) {
      case 'APPROVED':
        dot = AppColors.approved; bg = AppColors.approvedBg; text = AppColors.approved;
        break;
      case 'REJECTED':
        dot = AppColors.rejected; bg = AppColors.rejectedBg; text = AppColors.rejected;
        break;
      default:
        dot = AppColors.pending; bg = AppColors.pendingBg; text = const Color(0xFFB45309);
    }
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: context.getWidth(8),
        vertical: context.getHeight(3),
      ),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(context.getWidth(999)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: context.getWidth(6),
            height: context.getWidth(6),
            decoration: BoxDecoration(color: dot, shape: BoxShape.circle),
          ),
          SizedBox(width: context.getWidth(4)),
          Text(
            status,
            style: TextStyle(
              fontSize: context.getFontSize(10),
              color: text,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

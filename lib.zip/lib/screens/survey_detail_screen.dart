// ─────────────────────────────────────────────────────────────────────────────
// SurveyDetailScreen — Review Survey Details
// Changes:
//   • Removed History tab (now 3 tabs only)
//   • Survey Photos are NOT shown by default — opened via tap on Reviewed Images
//   • Fullscreen zoomable + swipeable image viewer with approve/reject
//   • Blocks survey approval if any photo is rejected
// ─────────────────────────────────────────────────────────────────────────────
import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/app_dimensions.dart';
import '../models/survey_model.dart';
import '../widgets/survey_map_widget.dart';
import '../widgets/info_field_pair.dart';
import '../widgets/reviewed_images_table.dart';

// ── Dummy photo data ──────────────────────────────────────────────────────────
class SurveyPhoto {
  final String url;
  final String date;
  final String location;
  final String device;

  const SurveyPhoto({
    required this.url,
    required this.date,
    required this.location,
    required this.device,
  });
}

enum PhotoStatus { pending, approved, rejected }

const List<SurveyPhoto> _dummyPhotos = [
  SurveyPhoto(
    url: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
    date: 'Oct 24, 2023',
    location: '1.288, 38.817',
    device: 'iPhone 14',
  ),
  SurveyPhoto(
    url: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800&q=80',
    date: 'Oct 24, 2023',
    location: '1.289, 38.820',
    device: 'iPhone 14',
  ),
  SurveyPhoto(
    url: 'https://images.unsplash.com/photo-1595841696677-6489ff3f8cd1?w=800&q=80',
    date: 'Oct 24, 2023',
    location: '1.290, 38.825',
    device: 'iPhone 14',
  ),
];

// ─────────────────────────────────────────────────────────────────────────────

class SurveyDetailScreen extends StatefulWidget {
  final List<SurveyModel> surveys;
  final int initialIndex;

  const SurveyDetailScreen({
    super.key,
    required this.surveys,
    required this.initialIndex,
  });

  @override
  State<SurveyDetailScreen> createState() => _SurveyDetailScreenState();
}

class _SurveyDetailScreenState extends State<SurveyDetailScreen>
    with TickerProviderStateMixin {
  late int _idx;
  late TabController _tabController;

  int _selection = 0;

  // Per-survey photo statuses: surveyId -> list of PhotoStatus
  final Map<String, List<PhotoStatus>> _photoStatuses = {};

  @override
  void initState() {
    super.initState();
    _idx = widget.initialIndex;
    _tabController = TabController(length: 3, vsync: this);
    _initPhotosForSurvey();
  }

  void _initPhotosForSurvey() {
    final id = _survey.id;
    if (!_photoStatuses.containsKey(id)) {
      _photoStatuses[id] =
          List.generate(_dummyPhotos.length, (_) => PhotoStatus.pending);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  SurveyModel get _survey => widget.surveys[_idx];

  List<PhotoStatus> get _currentStatuses =>
      _photoStatuses[_survey.id] ??
      List.generate(_dummyPhotos.length, (_) => PhotoStatus.pending);

  bool get _hasRejectedPhoto =>
      _currentStatuses.any((s) => s == PhotoStatus.rejected);

  bool get _isActioned =>
      _survey.status == SurveyStatus.approved ||
      _survey.status == SurveyStatus.rejected;

  void _goPrevious() {
    if (_idx > 0) {
      setState(() {
        _idx--;
        _selection = 0;
        _tabController.index = 0;
        _initPhotosForSurvey();
      });
    }
  }

  void _goNext() {
    if (_idx < widget.surveys.length - 1) {
      setState(() {
        _idx++;
        _selection = 0;
        _tabController.index = 0;
        _initPhotosForSurvey();
      });
    }
  }

  void _submit() {
    if (_selection == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please select Approve or Reject before submitting.'),
          backgroundColor: AppColors.pending,
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.all(context.getWidth(16)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(context.getWidth(10)),
          ),
        ),
      );
      return;
    }

    if (_selection == 1 && _hasRejectedPhoto) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
              'Cannot approve: one or more survey photos have been rejected.'),
          backgroundColor: AppColors.rejected,
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.all(context.getWidth(16)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(context.getWidth(10)),
          ),
        ),
      );
      return;
    }

    final approve = _selection == 1;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(context.getWidth(16)),
        ),
        title: Text(
          approve ? 'Approve Survey?' : 'Reject Survey?',
          style: TextStyle(
            color: approve ? AppColors.approved : AppColors.rejected,
            fontWeight: FontWeight.w700,
            fontSize: context.getFontSize(AppDimens.fontL),
          ),
        ),
        content: Text(
          approve
              ? 'Survey ${_survey.surveyNo} will be marked as approved.'
              : 'Survey ${_survey.surveyNo} will be rejected and sent for re-verification.',
          style: TextStyle(
            fontSize: context.getFontSize(AppDimens.fontM),
            color: AppColors.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel',
                style: TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: context.getFontSize(AppDimens.fontM))),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              setState(() {
                _survey.status =
                    approve ? SurveyStatus.approved : SurveyStatus.rejected;
              });
              if (_idx < widget.surveys.length - 1) {
                Future.delayed(const Duration(milliseconds: 400), _goNext);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: approve ? AppColors.approved : AppColors.rejected,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.getWidth(8))),
            ),
            child: Text(approve ? 'Approve' : 'Reject',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: context.getFontSize(AppDimens.fontM))),
          ),
        ],
      ),
    );
  }

  void _cancel() => setState(() => _selection = 0);

  String _fmt(DateTime dt) {
    final d = dt.day.toString().padLeft(2, '0');
    final mo = dt.month.toString().padLeft(2, '0');
    final h = dt.hour.toString().padLeft(2, '0');
    final mi = dt.minute.toString().padLeft(2, '0');
    final ap = dt.hour < 12 ? 'AM' : 'PM';
    return '$d/$mo/${dt.year} $h:$mi $ap';
  }

  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            _buildSequenceNav(),
            _buildWarningBanner(),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildFirstSurveyTab(),
                  _buildEmptyTab('2nd Survey', Icons.image_search_rounded),
                  _buildEmptyTab('Verification Survey', Icons.verified_outlined),
                ],
              ),
            ),
            _buildBottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      color: AppColors.surface,
      padding: EdgeInsets.fromLTRB(context.getWidth(4), context.getHeight(6),
          context.getWidth(12), context.getHeight(6)),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_rounded,
                color: AppColors.textPrimary,
                size: context.getWidth(AppDimens.iconL)),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('SURVEYOR TASK MANAGEMENT',
                    style: TextStyle(
                        fontSize: context.getFontSize(9),
                        color: AppColors.textMuted,
                        letterSpacing: 0.8,
                        fontWeight: FontWeight.w600)),
                Text('Review Survey Details',
                    style: TextStyle(
                        fontSize: context.getFontSize(AppDimens.fontL),
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
              ],
            ),
          ),
          GestureDetector(
            onTap: _showOwnersSheet,
            child: Container(
              padding: EdgeInsets.symmetric(
                  horizontal: context.getWidth(12),
                  vertical: context.getHeight(7)),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(context.getWidth(8)),
                border: Border.all(
                    color: AppColors.primary.withValues(alpha: 0.3)),
              ),
              child: Text('View Owners',
                  style: TextStyle(
                      color: AppColors.primaryDark,
                      fontSize: context.getFontSize(AppDimens.fontS),
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSequenceNav() {
    final canPrev = _idx > 0;
    final canNext = _idx < widget.surveys.length - 1;
    return Container(
      color: AppColors.surface,
      padding: EdgeInsets.symmetric(
          horizontal: context.getWidth(AppDimens.spaceM),
          vertical: context.getHeight(10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _navBtn(
              label: 'Previous',
              icon: Icons.chevron_left_rounded,
              leading: true,
              enabled: canPrev,
              onTap: _goPrevious),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('SURVEY SEQUENCE',
                  style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontXS),
                      color: AppColors.textMuted,
                      letterSpacing: 0.7,
                      fontWeight: FontWeight.w600)),
              SizedBox(height: context.getHeight(2)),
              RichText(
                text: TextSpan(
                  style: TextStyle(
                      fontSize: context.getFontSize(13),
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500),
                  children: [
                    TextSpan(
                        text: '${_idx + 1}',
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: context.getFontSize(15),
                            color: AppColors.textPrimary)),
                    const TextSpan(text: ' of '),
                    TextSpan(text: '${_survey.totalSequence}'),
                  ],
                ),
              ),
            ],
          ),
          _navBtn(
              label: 'Next',
              icon: Icons.chevron_right_rounded,
              leading: false,
              enabled: canNext,
              onTap: _goNext),
        ],
      ),
    );
  }

  Widget _navBtn({
    required String label,
    required IconData icon,
    required bool leading,
    required bool enabled,
    required VoidCallback onTap,
  }) {
    final color = enabled ? AppColors.primaryDark : AppColors.textMuted;
    final iconW = Icon(icon, size: context.getWidth(18), color: color);
    final labelW = Text(label,
        style: TextStyle(
            fontSize: context.getFontSize(AppDimens.fontS),
            color: color,
            fontWeight: FontWeight.w600));
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: leading ? [iconW, labelW] : [labelW, iconW],
      ),
    );
  }

  Widget _buildWarningBanner() {
    return Container(
      width: double.infinity,
      color: AppColors.pendingBg,
      padding: EdgeInsets.symmetric(
          horizontal: context.getWidth(14), vertical: context.getHeight(8)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded,
              size: context.getWidth(14), color: AppColors.pending),
          SizedBox(width: context.getWidth(6)),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: TextStyle(
                    fontSize: context.getFontSize(AppDimens.fontXS + 1),
                    color: const Color(0xFFB45309),
                    fontWeight: FontWeight.w500),
                children: const [
                  TextSpan(
                      text: 'Important Reminder: ',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                  TextSpan(
                      text:
                          'Before giving final approval or rejection of a survey, '
                          'please review all the surveyed images carefully.'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 3 tabs — History removed
  Widget _buildTabBar() {
    return Container(
      color: AppColors.surface,
      child: TabBar(
        controller: _tabController,
        labelColor: AppColors.primaryDark,
        unselectedLabelColor: AppColors.textSecondary,
        indicatorColor: AppColors.primary,
        indicatorWeight: 2.5,
        isScrollable: true,
        tabAlignment: TabAlignment.start,
        labelStyle: TextStyle(
            fontSize: context.getFontSize(AppDimens.fontS),
            fontWeight: FontWeight.w700),
        unselectedLabelStyle: TextStyle(
            fontSize: context.getFontSize(AppDimens.fontS),
            fontWeight: FontWeight.w500),
        tabs: const [
          Tab(text: '1st Survey'),
          Tab(text: '2nd Survey'),
          Tab(text: 'Verification Survey'),
        ],
      ),
    );
  }

  Widget _buildFirstSurveyTab() {
    final s = _survey;
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.all(context.getWidth(AppDimens.spaceM)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Survey Details',
              style: TextStyle(
                  fontSize: context.getFontSize(AppDimens.fontXL),
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          SizedBox(height: context.getHeight(12)),
          SurveyMapWidget(
              coordinateLabel: s.mapCoordinateLabel,
              isActual: s.status == SurveyStatus.pending),
          SizedBox(height: context.getHeight(16)),
          _buildInfoCard(s),
          SizedBox(height: context.getHeight(14)),
          // Survey Photos card is REMOVED from here.
          // Photos are accessed by tapping an image in the Reviewed Images table.
          _buildReviewedImagesCard(s),
          SizedBox(height: context.getHeight(24)),
        ],
      ),
    );
  }

  // ── Opens fullscreen viewer starting at the given photo index ─────────────
  void _openFullscreen(int startIndex) {
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => _FullscreenPhotoViewer(
          photos: _dummyPhotos,
          initialIndex: startIndex,
          photoStatuses: List<PhotoStatus>.from(_currentStatuses),
          onStatusChanged: (idx, status) {
            final id = _survey.id;
            final list = List<PhotoStatus>.from(_currentStatuses);
            list[idx] = status;
            setState(() => _photoStatuses[id] = list);
          },
        ),
      ),
    );
  }

  Widget _buildInfoCard(SurveyModel s) {
    return _card(
      child: Column(
        children: [
          InfoFieldPair(
              leftLabel: 'Owner Name',
              leftValue: s.ownerName,
              rightLabel: 'Taluka',
              rightValue: s.taluka),
          _divider(),
          InfoFieldPair(
              leftLabel: 'Village',
              leftValue: s.village,
              rightLabel: 'Survey No.',
              rightValue: s.surveyNo),
          _divider(),
          InfoFieldPair(
              leftLabel: 'Farmland Plot ID',
              leftValue: s.farmlandPlotId,
              rightLabel: 'Farmer Total Area',
              rightValue: '${s.farmerTotalArea.toStringAsFixed(3)} -'),
          _divider(),
          InfoFieldPair(
              leftLabel: 'Farm Allocation',
              leftValue: _fmt(s.farmAllocation),
              rightLabel: 'Surveyor Name',
              rightValue: s.surveyorName),
          _divider(),
          InfoFieldPair(
              leftLabel: 'Survey Date',
              leftValue: _fmt(s.surveyDate),
              rightLabel: 'Submission Date',
              rightValue: _fmt(s.submissionDate)),
          _divider(),
          InfoFieldPair(
              leftLabel: 'Latitude',
              leftValue: s.latitude.toStringAsFixed(6),
              rightLabel: 'Longitude',
              rightValue: s.longitude.toStringAsFixed(5)),
        ],
      ),
    );
  }

  // ── Reviewed Images card — tapping an image row opens the fullscreen viewer
  Widget _buildReviewedImagesCard(SurveyModel s) {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Total Reviewed Images',
                  style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontM),
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              SizedBox(width: context.getWidth(6)),
              Container(
                padding: EdgeInsets.symmetric(
                    horizontal: context.getWidth(7),
                    vertical: context.getHeight(2)),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(
                      context.getWidth(AppDimens.radiusFull)),
                ),
                child: Text('${s.reviewedImages.length}/${s.reviewedImages.length}',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: context.getFontSize(AppDimens.fontXS),
                        fontWeight: FontWeight.w700)),
              ),
              SizedBox(width: context.getWidth(4)),
              Icon(Icons.info_outline_rounded,
                  size: context.getWidth(14), color: AppColors.textMuted),
            ],
          ),
          SizedBox(height: context.getHeight(4)),
          // Hint text so users know images are tappable
          Text(
            'Tap an image to review in full screen',
            style: TextStyle(
              fontSize: context.getFontSize(AppDimens.fontXS),
              color: AppColors.textMuted,
              fontStyle: FontStyle.italic,
            ),
          ),
          SizedBox(height: context.getHeight(8)),
          // Pass openFullscreen callback into the table widget
          ReviewedImagesTable(
            images: s.reviewedImages,
            onImageTap: _openFullscreen,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyTab(String title, IconData icon) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: context.getWidth(52), color: AppColors.divider),
          SizedBox(height: context.getHeight(16)),
          Text('No $title Data',
              style: TextStyle(
                  fontSize: context.getFontSize(AppDimens.fontL),
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600)),
          SizedBox(height: context.getHeight(6)),
          Text('Data has not been submitted yet.',
              style: TextStyle(
                  fontSize: context.getFontSize(AppDimens.fontS),
                  color: AppColors.textMuted)),
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(context.getWidth(14), context.getHeight(12),
          context.getWidth(14), context.getHeight(16)),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.divider)),
        boxShadow: [
          BoxShadow(
              color: AppColors.shadowMedium,
              blurRadius: 10,
              offset: Offset(0, -3))
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Rejected-photo block warning
          if (_hasRejectedPhoto && !_isActioned)
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(bottom: context.getHeight(8)),
              padding: EdgeInsets.symmetric(
                  horizontal: context.getWidth(12),
                  vertical: context.getHeight(7)),
              decoration: BoxDecoration(
                color: AppColors.rejectedBg,
                borderRadius: BorderRadius.circular(context.getWidth(8)),
                border: Border.all(
                    color: AppColors.rejected.withValues(alpha: 0.5)),
              ),
              child: Row(
                children: [
                  Icon(Icons.block_rounded,
                      color: AppColors.rejected,
                      size: context.getWidth(14)),
                  SizedBox(width: context.getWidth(6)),
                  Expanded(
                    child: Text(
                      'Survey approval is blocked: one or more photos were rejected.',
                      style: TextStyle(
                          color: AppColors.rejected,
                          fontSize:
                              context.getFontSize(AppDimens.fontXS + 1),
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),

          // Already-actioned banner
          if (_isActioned)
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(bottom: context.getHeight(10)),
              padding:
                  EdgeInsets.symmetric(vertical: context.getHeight(9)),
              decoration: BoxDecoration(
                color: _survey.status == SurveyStatus.approved
                    ? AppColors.approvedBg
                    : AppColors.rejectedBg,
                borderRadius: BorderRadius.circular(context.getWidth(8)),
                border: Border.all(
                  color: _survey.status == SurveyStatus.approved
                      ? AppColors.approved
                      : AppColors.rejected,
                ),
              ),
              child: Text(
                _survey.status == SurveyStatus.approved
                    ? '✓  Survey Approved'
                    : '✕  Rejected & Sent for Reverification',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: _survey.status == SurveyStatus.approved
                        ? AppColors.approved
                        : AppColors.rejected,
                    fontWeight: FontWeight.w700,
                    fontSize: context.getFontSize(AppDimens.fontM)),
              ),
            ),

          if (!_isActioned) ...[
            Row(
              children: [
                _radioOption(
                    value: 1,
                    label: 'Approve',
                    activeColor: AppColors.approved,
                    disabled: _hasRejectedPhoto),
                SizedBox(width: context.getWidth(8)),
                _radioOption(
                    value: 2,
                    label: 'Reject & send for Reverification',
                    activeColor: AppColors.rejected,
                    disabled: false),
              ],
            ),
            SizedBox(height: context.getHeight(10)),
          ],

          Row(
            children: [
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: context.getHeight(44),
                  child: OutlinedButton(
                    onPressed: _isActioned ? null : _cancel,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.divider),
                      backgroundColor: AppColors.surfaceMuted,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              context.getWidth(AppDimens.radiusS))),
                    ),
                    child: Text('Cancel',
                        style: TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w600,
                            fontSize:
                                context.getFontSize(AppDimens.fontM))),
                  ),
                ),
              ),
              SizedBox(width: context.getWidth(10)),
              Expanded(
                flex: 3,
                child: SizedBox(
                  height: context.getHeight(44),
                  child: ElevatedButton(
                    onPressed: _isActioned ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      disabledBackgroundColor:
                          AppColors.primary.withValues(alpha: 0.4),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              context.getWidth(AppDimens.radiusS))),
                    ),
                    child: Text('Submit Selection',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize:
                                context.getFontSize(AppDimens.fontM))),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _radioOption({
    required int value,
    required String label,
    required Color activeColor,
    required bool disabled,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: disabled ? null : () => setState(() => _selection = value),
        behavior: HitTestBehavior.opaque,
        child: Opacity(
          opacity: disabled ? 0.4 : 1.0,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: context.getWidth(20),
                height: context.getWidth(20),
                child: Radio<int>(
                  value: value,
                  groupValue: _selection,
                  onChanged:
                      disabled ? null : (v) => setState(() => _selection = v!),
                  activeColor: activeColor,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  visualDensity: VisualDensity.compact,
                ),
              ),
              SizedBox(width: context.getWidth(4)),
              Flexible(
                child: Text(label,
                    style: TextStyle(
                        fontSize: context.getFontSize(AppDimens.fontS),
                        fontWeight: FontWeight.w600,
                        color: (_selection == value && !disabled)
                            ? AppColors.textPrimary
                            : AppColors.textSecondary)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(context.getWidth(14)),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius:
            BorderRadius.circular(context.getWidth(AppDimens.radiusM)),
        border: Border.all(color: AppColors.divider),
        boxShadow: const [
          BoxShadow(
              color: AppColors.shadowLight,
              blurRadius: 8,
              offset: Offset(0, 3))
        ],
      ),
      child: child,
    );
  }

  Widget _divider() => Padding(
        padding:
            EdgeInsets.symmetric(vertical: context.getHeight(10)),
        child: const Divider(height: 1, color: AppColors.divider),
      );

  void _showOwnersSheet() {
    final s = _survey;
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(context.getWidth(AppDimens.radiusL))),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.all(context.getWidth(AppDimens.spaceM)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: context.getWidth(36),
                height: context.getHeight(4),
                decoration: BoxDecoration(
                    color: AppColors.divider,
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            SizedBox(height: context.getHeight(14)),
            Text('Survey Owners',
                style: TextStyle(
                    fontSize: context.getFontSize(AppDimens.fontXL),
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary)),
            SizedBox(height: context.getHeight(16)),
            _ownerTile(ctx, 'Primary Owner', s.ownerName, Icons.person_rounded),
            Divider(color: AppColors.divider, height: context.getHeight(1)),
            _ownerTile(
                ctx, 'Surveyor', s.surveyorName, Icons.engineering_rounded),
            Divider(color: AppColors.divider, height: context.getHeight(1)),
            _ownerTile(ctx, 'Region', '${s.village}, ${s.taluka}',
                Icons.location_on_rounded),
            SizedBox(height: context.getHeight(20)),
          ],
        ),
      ),
    );
  }

  Widget _ownerTile(
      BuildContext ctx, String label, String value, IconData icon) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: context.getHeight(10)),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(context.getWidth(8)),
            decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(context.getWidth(8))),
            child: Icon(icon,
                color: AppColors.primaryDark,
                size: context.getWidth(AppDimens.iconM)),
          ),
          SizedBox(width: context.getWidth(12)),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontXS),
                      color: AppColors.textMuted)),
              Text(value,
                  style: TextStyle(
                      fontSize: context.getFontSize(AppDimens.fontM),
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary)),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Fullscreen Zoomable Photo Viewer
// ─────────────────────────────────────────────────────────────────────────────
class _FullscreenPhotoViewer extends StatefulWidget {
  final List<SurveyPhoto> photos;
  final int initialIndex;
  final List<PhotoStatus> photoStatuses;
  final void Function(int index, PhotoStatus status) onStatusChanged;

  const _FullscreenPhotoViewer({
    required this.photos,
    required this.initialIndex,
    required this.photoStatuses,
    required this.onStatusChanged,
  });

  @override
  State<_FullscreenPhotoViewer> createState() => _FullscreenPhotoViewerState();
}

class _FullscreenPhotoViewerState extends State<_FullscreenPhotoViewer> {
  late int _current;
  late List<PhotoStatus> _statuses;
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _current = widget.initialIndex;
    _statuses = List<PhotoStatus>.from(widget.photoStatuses);
    _pageController = PageController(initialPage: _current);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _toggleStatus(PhotoStatus s) {
    final next = _statuses[_current] == s ? PhotoStatus.pending : s;
    setState(() => _statuses[_current] = next);
    widget.onStatusChanged(_current, next);
  }

  @override
  Widget build(BuildContext context) {
    final photo = widget.photos[_current];
    final status = _statuses[_current];
    final isApproved = status == PhotoStatus.approved;
    final isRejected = status == PhotoStatus.rejected;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Swipeable + zoomable pages
          PageView.builder(
            controller: _pageController,
            itemCount: widget.photos.length,
            onPageChanged: (i) => setState(() => _current = i),
            itemBuilder: (ctx, idx) => InteractiveViewer(
              minScale: 0.8,
              maxScale: 5.0,
              child: Center(
                child: Image.network(
                  widget.photos[idx].url,
                  fit: BoxFit.contain,
                  loadingBuilder: (ctx, child, progress) {
                    if (progress == null) return child;
                    return const Center(
                        child: CircularProgressIndicator(
                            color: AppColors.primary));
                  },
                ),
              ),
            ),
          ),

          // Top bar
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              color: Colors.black.withValues(alpha: 0.6),
              padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top + 8,
                  bottom: 12, left: 8, right: 16),
              child: Row(
                children: [
                  // "REVIEW X of Y" badge
                  Container(
                    margin: const EdgeInsets.only(left: 4),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.approved,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      'REVIEW ${_current + 1} of ${widget.photos.length} images',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 12),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded,
                        color: Colors.white, size: 26),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),

          // Bottom bar
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              color: Colors.black.withValues(alpha: 0.75),
              padding: EdgeInsets.fromLTRB(16, 12, 16,
                  MediaQuery.of(context).padding.bottom + 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Dot indicators
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      widget.photos.length,
                      (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _current == i ? 18 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _current == i
                              ? Colors.white
                              : Colors.white.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Approve / Reject buttons
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton.icon(
                            onPressed: () =>
                                // _toggleStatus(PhotoStatus.rejected),
                                {
                                  _toggleStatus(PhotoStatus.rejected),
                                  Navigator.pop(context),
                                },

                            icon: Icon(
                              Icons.cancel_rounded,
                              size: 18,
                              color: isRejected
                                    ? Colors.white
                                    : AppColors.rejected),
                            label: Text('Reject Photo',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    color: isRejected
                                        ? Colors.white
                                        : AppColors.rejected)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isRejected
                                  ? AppColors.rejected
                                  : Colors.white.withValues(alpha: 0.12),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(
                                    color: AppColors.rejected
                                        .withValues(alpha: 0.6)),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton.icon(
                            onPressed: () =>
                                _toggleStatus(PhotoStatus.approved),
                            icon: Icon(Icons.check_circle_rounded,
                                size: 18,
                                color: isApproved
                                    ? Colors.white
                                    : AppColors.approved),
                            label: Text('Approve Photo',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    color: isApproved
                                        ? Colors.white
                                        : AppColors.approved)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isApproved
                                  ? AppColors.approved
                                  : Colors.white.withValues(alpha: 0.12),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(
                                    color: AppColors.approved
                                        .withValues(alpha: 0.6)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  // Meta row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.calendar_today_rounded,
                          color: Colors.white54, size: 12),
                      const SizedBox(width: 4),
                      Text(photo.date,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12)),
                      const SizedBox(width: 12),
                      const Icon(Icons.location_on_rounded,
                          color: Colors.white54, size: 12),
                      const SizedBox(width: 4),
                      Text(photo.location,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12)),
                      const SizedBox(width: 12),
                      const Icon(Icons.smartphone_rounded,
                          color: Colors.white54, size: 12),
                      const SizedBox(width: 4),
                      Text(photo.device,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Left nav arrow
          if (_current > 0)
            Positioned(
              left: 8, top: 0, bottom: 0,
              child: Center(
                child: GestureDetector(
                  onTap: () => _pageController.previousPage(
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeInOut),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.45),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.chevron_left_rounded,
                        color: Colors.white, size: 28),
                  ),
                ),
              ),
            ),

          // Right nav arrow
          if (_current < widget.photos.length - 1)
            Positioned(
              right: 8, top: 0, bottom: 0,
              child: Center(
                child: GestureDetector(
                  onTap: () => _pageController.nextPage(
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeInOut),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.45),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.chevron_right_rounded,
                        color: Colors.white, size: 28),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
